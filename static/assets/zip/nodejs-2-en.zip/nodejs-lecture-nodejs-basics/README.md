# Examples from ["Express yourself with Node.js" lecture](https://binary-studio-academy.github.io/stage-2/lectures/express-yourself-with-nodejs/en)

1. [nodejs-basics](https://github.com/uliana-lobanova/nodejs-lecture/tree/nodejs-basics)
2. [expressjs-basics](https://github.com/uliana-lobanova/nodejs-lecture/tree/expressjs-basics)
3. [project structure](https://github.com/uliana-lobanova/nodejs-lecture/tree/project-structure)
4. [debugging](https://github.com/uliana-lobanova/nodejs-lecture/tree/main)
